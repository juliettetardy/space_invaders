Les zinzins de l'espace débarquent sur terre... pour nous envahir !
Il n'y a qu'une seule solution pour les arrêter : leur tirer dessus et les détruire avant qu’ils ne nous détruisent!

Pour cela, c'est très simple. Vous incarnez le vaisseau en bas de l'écran. Les aliens quant à eux se situent en haut de l'écran et se déplace de droite à gauche.
Les aliens tirent de manière aléatoire des missiles, il faut faire attention à les esquiver sinon quoi au bout de trois missiles reçus, votre vaisseau sera détruit et vous aurez perdu.

Mais alors comment les éliminer ? Votre vaisseau a la capacité de se déplacer de gauche à droite en utilisant les touches '<' ou '>' de votre clavier. Grâce à cela, vous pourrez viser afin d'envoyer des missiles vous aussi. 
Pour envoyer un missile, il suffit d'appuyer sur la touche espace.

Vous pouvez également vous protéger grâce aux ilots protecteurs gris. Mais attention, ils sont détruit au fur et à mesure que les missiles les touchent !

Attention encore... Les aliens se déplacent en se rapprochant de votre vaisseau. Si ils vous touchent, vous avez perdu !

Alors détruisez tous les aliens avant de perdre vos trois vies ou de vous faire tuer ! 
De plus, vous ne serez jamais au bout de vos surprises... Le super méga ultra alien a lui aussi décidé de débarquer. Tirez lui 10 fois dessus avant qu'il ne meure afin de gagner la partie !

Chaque alien tué vous rapporte 10 points.
Chaque missile qui atteint le vaisseau vous fait perdre 20 points.
Si le boss final vous touche, il vous fait perdre 30 points.
Le boss final lui, vous fait gagner 150 points !

Alors explosez les scores, explosez les et sauvez la galaxie !



